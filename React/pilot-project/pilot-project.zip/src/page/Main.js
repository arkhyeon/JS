import React from "react";

function Main({ getTheme }) {
    return (
        <div>
            Main
            <button onClick={() => getTheme("dark")}>테마 변경</button>
            <button onClick={() => getTheme("light")}>테마 변경</button>
        </div>
    );
}

export default Main;
